import snc.boot.boot.Boot;
import org.apache.log4j.Logger;

public class BootStart {
    public static void main(String[] args) {
        Boot.start();
    }
}