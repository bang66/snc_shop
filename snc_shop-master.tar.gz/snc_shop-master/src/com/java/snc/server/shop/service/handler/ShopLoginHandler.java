package snc.server.shop.service.handler;

public class ShopLoginHandler {
}
