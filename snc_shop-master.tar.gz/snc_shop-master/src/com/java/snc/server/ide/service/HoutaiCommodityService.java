package snc.server.ide.service;

import snc.server.ide.pojo.HoutaiCommodity;

public interface HoutaiCommodityService {
    public void insertCommodity(HoutaiCommodity h);
}
