package snc.server.ide.service.handler;

public class GiftInterfaceHandler {
}
