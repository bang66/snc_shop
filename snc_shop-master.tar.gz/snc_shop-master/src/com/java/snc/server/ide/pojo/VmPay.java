package snc.server.ide.pojo;

public class VmPay {
    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    private boolean state ;

}
