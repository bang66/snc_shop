package snc.server.ide.pojo;


public class Gift {

    private String mod;

    private String g_detaile;//描述

    private String g_id;
    private String g_name;
    private String g_image;
    private String g_sold;//购买数量
    private String g_stock;//库存
    private String g_price;//礼物积分
    private String g_col;//颜色
    private String g_size;

    public String getMod() {
        return mod;
    }

    public void setMod(String mod) {
        this.mod = mod;
    }

    public String getG_detaile() {
        return g_detaile;
    }

    public void setG_detaile(String g_detaile) {
        this.g_detaile = g_detaile;
    }

    public String getG_col() {
        return g_col;
    }

    public void setG_col(String g_col) {
        this.g_col = g_col;
    }

    public String getG_size() {
        return g_size;
    }

    public void setG_size(String g_size) {
        this.g_size = g_size;
    }

    public String getG_id() {
        return g_id;
    }

    public void setG_id(String g_id) {
        this.g_id = g_id;
    }

    public String getG_name() {
        return g_name;
    }

    public void setG_name(String g_name) {
        this.g_name = g_name;
    }



    public String getG_image() {
        return g_image;
    }

    public void setG_image(String g_image) {
        this.g_image = g_image;
    }

    public String getG_sold() {
        return g_sold;
    }

    public void setG_sold(String g_sold) {
        this.g_sold = g_sold;
    }


    public String getG_stock() {
        return g_stock;
    }

    public void setG_stock(String g_stock) {
        this.g_stock = g_stock;
    }

    public String getG_price() {
        return g_price;
    }

    public void setG_price(String g_price) {
        this.g_price = g_price;
    }


    }
