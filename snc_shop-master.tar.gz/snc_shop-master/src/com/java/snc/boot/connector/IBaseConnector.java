package snc.boot.connector;

public interface IBaseConnector {

}
