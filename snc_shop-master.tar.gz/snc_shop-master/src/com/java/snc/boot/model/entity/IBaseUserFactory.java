package snc.boot.model.entity;

public interface IBaseUserFactory {

}
