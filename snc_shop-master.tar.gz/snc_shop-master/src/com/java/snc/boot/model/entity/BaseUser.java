package snc.boot.model.entity;

import io.netty.channel.Channel;

public class BaseUser implements IBaseCharacter{
    protected Channel channel;

}
