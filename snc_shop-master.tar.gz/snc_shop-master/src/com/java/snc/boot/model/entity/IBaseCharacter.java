package snc.boot.model.entity;

import io.netty.channel.Channel;

import java.util.Map;

public interface IBaseCharacter {
}
