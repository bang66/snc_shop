package snc.boot.util;

public class ESUtil {
}
