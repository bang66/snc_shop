package snc.boot.util.common;

/**
 * Created by jac on 18-11-12.
 */
public interface IBaseHandler {

    String getHandlerName();

    void setHandlerName(String handlerName);
}
