package snc.boot.message;

/**
 * Created by jac on 18-11-12.
 */
public interface IBaseMessage {
    String toString();

    String getH();

    void setH(String h);

}
